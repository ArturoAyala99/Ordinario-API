# UIAPI

1. acceda a una pantalla de la terminal dentro de la carpeta "db" y ejecute el comando "docker-compose up".

2. Para acceder a los datos de la base de datos puede utilizar cualquier administrador de base de datos, accediendo con las siguientes credenciales:
usuario: mydbuser
contraseña: mydbpassword
puerto: 3306
las tablas que contienen la informacion son "videogames" y "rating"

3.acceda a una pantalla de la terminal dentro de la carpeta "DjangoApi-master" y ejecute el comando "docker-compose up".

4. Una vez realizado esto podrás interactuar con la API accediendo a la interfaz en el navegador. para esto debes escribir la direccion "http://localhost:8000", desde donde podras ver la informacion guardada en la BD, asi como interactuar con ella


NOTA: Para Poder ejecutar este proyecto es necesario que cuentes con la  aplicación de "Docker Desktop" instalada en tu dispositivo. Si no la tienes, puedes descargarla desde https://www.docker.com
